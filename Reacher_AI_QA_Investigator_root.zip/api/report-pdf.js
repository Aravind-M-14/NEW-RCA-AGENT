import PDFDocument from "pdfkit";

const clean = (v) => String(v ?? "—").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
const arr = (v) => Array.isArray(v) ? v : [];

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }
  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : (req.body || {});
    const r = body.report;
    if (!r || !r.validity || !r.rca) return res.status(400).json({ error: "A complete investigation report is required to generate the PDF." });

    const doc = new PDFDocument({ size: "A4", margins: { top: 52, bottom: 52, left: 54, right: 54 }, info: { Title: `Reacher RCA — ${clean(r.incident?.ticket_id)}`, Author: "Reacher — AI QA Investigator" } });
    const chunks = [];
    doc.on("data", c => chunks.push(c));
    doc.on("end", () => {
      const buffer = Buffer.concat(chunks);
      const safeId = clean(r.incident?.ticket_id || "incident").replace(/[^a-zA-Z0-9-_]/g, "-").slice(0, 64);
      res.status(200);
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="reacher-${safeId}-rca-report.pdf"`);
      res.setHeader("Content-Length", buffer.length);
      res.end(buffer);
    });

    const navy = "#14243B", teal = "#0D9488", muted = "#5B6778", red = "#B42318", light = "#E8F2F3";
    const width = doc.page.width - doc.page.margins.left - doc.page.margins.right;
    const ensure = (needed = 75) => { if (doc.y + needed > doc.page.height - doc.page.margins.bottom) doc.addPage(); };
    const title = (txt) => { ensure(40); doc.moveDown(0.5).font("Helvetica-Bold").fontSize(15).fillColor(navy).text(clean(txt)); doc.moveDown(0.25); };
    const subtitle = (txt) => { ensure(28); doc.font("Helvetica-Bold").fontSize(10.5).fillColor(teal).text(clean(txt)); doc.moveDown(0.2); };
    const para = (txt) => { ensure(38); doc.font("Helvetica").fontSize(9.5).fillColor("#202A37").text(clean(txt), { width, lineGap: 2 }); doc.moveDown(0.35); };
    const list = (items) => { const xs = arr(items); if (!xs.length) return para("None supplied."); xs.forEach(x => { ensure(30); doc.font("Helvetica").fontSize(9.2).fillColor("#202A37").text("•  " + clean(x), { width: width - 6, indent: 6, lineGap: 2 }); doc.moveDown(0.18); }); doc.moveDown(0.2); };
    const callout = (label, text, color = teal) => {
      ensure(70); const y = doc.y; doc.roundedRect(doc.page.margins.left, y, width, 58, 7).fill(color === red ? "#FFF1F0" : light);
      doc.fillColor(color).font("Helvetica-Bold").fontSize(9).text(clean(label), doc.page.margins.left + 12, y + 9, { width: width - 24 });
      doc.fillColor(navy).font("Helvetica").fontSize(10).text(clean(text), doc.page.margins.left + 12, y + 24, { width: width - 24, height: 31, ellipsis: true });
      doc.y = y + 68;
    };

    doc.rect(0, 0, doc.page.width, 118).fill(navy);
    doc.fillColor("#7DE2D1").font("Helvetica-Bold").fontSize(10).text("REACHER  /  AI QA INVESTIGATOR", 54, 38);
    doc.fillColor("#FFFFFF").font("Helvetica-Bold").fontSize(23).text("Production Incident RCA", 54, 58);
    doc.fillColor("#D3DCE7").font("Helvetica").fontSize(9).text(clean(r.incident?.ticket_id || "Ticket ID not supplied") + "  •  " + clean(r.meta?.generated_at || new Date().toISOString()), 54, 91);
    doc.y = 140;
    callout("ISSUE VALIDITY · " + clean(r.validity.label) + " · CONFIDENCE " + clean(r.validity.confidence), r.validity.reasoning, r.validity.label === "Confirmed defect" ? red : teal);
    title("Executive summary"); para(r.executive_summary);
    title("1. Incident reconstruction");
    [["Title",r.incident?.title],["Severity",r.incident?.severity],["Environment",r.incident?.environment],["Component",r.incident?.component],["Version",r.incident?.version],["Reported",r.incident?.reported_when],["Frequency",r.incident?.frequency],["Customer impact",r.incident?.customer_impact]].forEach(([k,v])=>{ subtitle(k); para(v); });
    subtitle("Reproduction steps"); list(r.incident?.reproduction_steps);
    subtitle("Timeline"); list(r.incident?.timeline);
    subtitle("Useful identifiers"); list(r.incident?.identifiers);

    title("2. Issue-validity assessment");
    subtitle("Expected behavior"); para(r.validity.expected_behavior);
    subtitle("Reported actual behavior"); para(r.validity.actual_behavior);
    subtitle("Evidence supporting the report"); list(r.validity.evidence_for);
    subtitle("Evidence against / alternative explanations"); list(r.validity.evidence_against);
    subtitle("Validation checks"); list(r.validity.validation_checks);
    subtitle("Next decision gate"); para(r.validity.next_gate);

    title("3. Evidence ledger"); subtitle("Observed facts"); list(r.evidence_ledger?.observed_facts);
    subtitle("Hypotheses / inferences"); list(r.evidence_ledger?.hypotheses);
    subtitle("Unknowns"); list(r.evidence_ledger?.unknowns);
    subtitle("Contradictions"); list(r.evidence_ledger?.contradictions);

    title("4. Root-cause investigation");
    callout("RCA STATUS · " + clean(r.rca.status) + " · CONFIDENCE " + clean(r.rca.confidence), r.rca.summary, r.rca.status === "Confirmed by evidence" ? red : teal);
    arr(r.rca.hypotheses).forEach((h,i)=>{ subtitle(`${i+1}. ${h.title} — plausibility: ${h.plausibility}`); para("Supporting evidence:"); list(h.supporting_evidence); para("Counter-evidence:"); list(h.counter_evidence); para("Confirmation steps:"); list(h.confirmation_steps); });

    title("5. Testing gaps / missed coverage"); arr(r.testing_gaps).forEach(g=>{ subtitle(g.area); para("Why it may have been missed: " + g.why_it_may_have_been_missed); para("Recommended coverage:"); list(g.recommended_coverage); });
    title("6. Actions"); subtitle("Immediate / containment"); list(r.actions?.immediate); subtitle("Corrective actions"); list(r.actions?.corrective); subtitle("Preventive actions"); list(r.actions?.preventive); subtitle("Safe customer guidance"); list(r.actions?.safe_customer_guidance);
    title("7. Reproduction strategy"); list(r.reproduction_strategy);
    title("8. Regression tests"); list(r.regression_tests);
    title("9. Suggested ownership"); list(r.ownership);
    title("10. Communication and closure guidance"); subtitle("Manager update"); para(r.communication?.manager_update); subtitle("Customer update"); para(r.communication?.customer_update); subtitle("Closure guidance"); para(r.communication?.closure_guidance);
    title("11. Final recommendation"); para(r.final_recommendation);
    title("12. Limitations and verification notes"); list(r.limitations);
    doc.moveDown(0.5); doc.font("Helvetica-Oblique").fontSize(8).fillColor(muted).text("AI-assisted analysis. Confirm findings against production logs, system state, requirements, and responsible engineering owners before taking irreversible action. This report does not itself change ticket status or execute production actions.", { width });
    doc.end();
  } catch (error) {
    console.error("PDF generation failed", error?.message);
    return res.status(500).json({ error: "Could not generate the PDF report. Run the analysis again and retry the download." });
  }
}
