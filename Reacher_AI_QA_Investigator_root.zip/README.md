# Reacher — AI QA Investigator

A deploy-ready, responsive Vercel web app built from the supplied Base44 Superagent instructions.

## Implemented workflow

- Agent identity: **Reacher**, professional QA manager; warm, efficient, sophisticated, direct, and evidence-first.
- The report first assesses whether the supplied report is likely to be a genuine defect, expected behavior, configuration/data/environment issue, duplicate, intermittent issue, potential security/privacy issue, or insufficient evidence.
- Only after issue validity does it perform root-cause investigation.
- Structured evidence ledger separates observed facts, hypotheses/inferences, unknowns, and contradictions.
- RCA hypotheses include supporting evidence, counter-evidence, and confirmation steps.
- Includes likely testing gaps/missed coverage, reproduction strategy, regression tests, immediate containment, corrective/preventive actions, suggested owners, and manager/customer communications.
- Produces a complete report in one pass and exposes a PDF download by default; it does not keep asking whether the user wants a report.
- Includes synthetic demo tickets for a high-evidence payment/order issue, an intermittent duplicate reservation, a possible expected-behavior report, and ambiguous stale inventory.
- Errors are shown in the UI, including missing environment variable, rejected API key, model availability, quota/rate limit, and non-JSON backend errors.

## Deploy to Vercel

1. Create a GitHub repository and upload the **contents** of this folder to the repository root (`index.html`, `package.json`, `api/`, `vercel.json`, `README.md`, `.gitignore`). Do not upload the enclosing folder as a nested subdirectory.
2. Import that repository in Vercel. Framework preset can be **Other**; no build command is needed for the static frontend. Vercel will detect the `api/` Node functions.
3. In Vercel → Project → Settings → Environment Variables, add `OPENAI_API_KEY` with your private API key. Select **Production** and **Preview** if you test preview branches. Never commit this key to GitHub or place it in browser code.
4. Optionally add `OPENAI_MODEL` with a model available to your OpenAI API project. The default in code is `gpt-6-luna`; use an available model name if your account does not have access to it.
5. Deploy/redeploy after setting variables. Environment changes do not apply to already-created deployments.
6. Test a demo ticket and download the PDF. Check the Vercel function logs if a request fails.

## Run locally

Requires Node.js and an OpenAI API key.

```bash
npm install
npx vercel dev
```

Create `.env.local` (do not commit it):

```text
OPENAI_API_KEY=your_private_key_here
OPENAI_MODEL=gpt-6-luna
```

## Important boundaries

- This app does not have a connection to Base44's private files/entities, your product's issue tracker, source control, databases, or production logs. It analyzes what the user supplies. Real integrations must be implemented separately and authorized.
- It does not run experiments, create external events, change ticket status, close tickets, roll back releases, reconcile payments, or contact customers. It proposes investigation steps only.
- A testing gap is a hypothesis unless test plans/results prove the gap. A root cause must not be marked confirmed without sufficient causal evidence.
- API usage is billed/limited by the OpenAI API account separately from Base44 credits. Protect and monitor API keys.
- This is a starter production deployment package. Before public launch, add authentication/rate limiting, request-size controls, observability, and privacy/data-retention review appropriate for your users.
